library(shiny)
library(ggplot2)
library(dplyr)
library(leaflet)
library(sf)
library(readr)
library(DT)
#set working directory
setwd("C:\\Users\\SAMUEL\\OneDrive\\Documentos\\2025\\Quinto semestre\\Visualizacion de datos\\actividad_mapas")
#cargar el shapelife
shapeC <- st_read("Departamento.shp")
shapeC <- st_transform(shapeC, crs = 4326)

datos <- read.csv("Data.csv")

departamentos_centroides <- st_point_on_surface(shapeC)


names(datos)
choices <-names(datos)[4:length(names(datos))] 



ui <- navbarPage("Tablero mapa indicadores educativos",
                
                 tabPanel("Mapa",
                          sidebarLayout(
                            sidebarPanel(
                              selectInput("year", "Selecciona el Año:", choices = unique(datos$AÑO)),
                              selectInput("Variable", "Seleccione la variable", choices =choices, "%Y")
                            ),
                            mainPanel(
                              leafletOutput("mapa")
                            )
                          )),
                 
                  tabPanel("Datos",
                           DTOutput("tablaDatos")
                  )
                 
)
server <- function(input, output) {
  
  output$mapa <- renderLeaflet({
    df <- datos %>%
      filter(input$year==AÑO) %>%
      group_by(DEPARTAMENTO) %>%
      summarise(!!input$Variable := mean(get(input$Variable), na.rm = TRUE))
    
    merged_data <- merge(shapeC, df, by.x = 'DeNombre', by.y = 'DEPARTAMENTO', all.x = TRUE)
    
    pal <- colorNumeric(palette = 'viridis', domain = merged_data[[input$Variable]])
    
    leaflet(merged_data) %>%
      addTiles() %>%
      addPolygons(fillColor = ~pal(merged_data[[input$Variable]]),
                  weight = 1, opacity = 1,
                  color = 'white', fillOpacity = 0.7,
                  popup = ~paste(DeNombre, '<br>',get(input$Variable) ))
    
  })
  output$tablaDatos <- renderDT({
    datatable(datos)
  })
}

shinyApp(ui = ui, server = server)

