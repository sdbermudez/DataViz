import dash
from dash import dcc, html, Input, Output, dash_table
import plotly.express as px
import pandas as pd
import geopandas as gpd
import json

import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

# Cargar shapefile y convertir a GeoJSON
shapeC = gpd.read_file("Departamento.shp").to_crs(epsg=4326)
shapeC["DeNombre"] = shapeC["DeNombre"].str.strip().str.lower()  # Limpiar nombres
geojson_departamentos = json.loads(shapeC.to_json())

# Cargar datos
datos = pd.read_csv("Data.csv")
datos["DEPARTAMENTO"] = datos["DEPARTAMENTO"].str.strip().str.lower()  # Limpiar nombres

# Variables disponibles
choices = datos.columns[3:]  # Tomamos las columnas desde la 4 en adelante

# Inicializar la app Dash
app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1("Tablero Mapa Indicadores Educativos"),
    
    # Controles de usuario
    html.Label("Selecciona el Año:"),
    dcc.Dropdown(
        id="year-dropdown",
        options=[{"label": str(y), "value": y} for y in sorted(datos["AÑO"].unique())],
        value=sorted(datos["AÑO"].unique())[0]
    ),

    html.Label("Selecciona la Variable:"),
    dcc.Dropdown(
        id="variable-dropdown",
        options=[{"label": v, "value": v} for v in choices],
        value=choices[0]
    ),

    # Mapa
    dcc.Graph(id="mapa"),

    # Tabla de datos
    html.H3("Datos Filtrados"),
    dash_table.DataTable(
        id="tabla-datos",
        columns=[{"name": col, "id": col} for col in datos.columns],
        page_size=10,
        style_table={"overflowX": "auto"}
    )
])

@app.callback(
    Output("mapa", "figure"),
    Output("tabla-datos", "data"),
    Input("year-dropdown", "value"),
    Input("variable-dropdown", "value")
)
def update_mapa(year, variable):
    # Filtrar datos por año
    df_filtrado = datos[datos["AÑO"] == year].copy()

    # Calcular la media de la variable por departamento
    df_agrupado = df_filtrado.groupby("DEPARTAMENTO", as_index=False)[variable].mean()

    # Unir datos con geometría
    shape_merge = shapeC.merge(df_agrupado, left_on="DeNombre", right_on="DEPARTAMENTO", how="left")

    # Crear el mapa coroplético
    fig = px.choropleth_mapbox(
        shape_merge,
        geojson=geojson_departamentos,
        locations="DeNombre",
        featureidkey="properties.DeNombre",
        color=variable,
        color_continuous_scale="viridis",
        mapbox_style="open-street-map",
        center={"lat": 4, "lon": -72},  # Centro de Colombia
        zoom=4,
        opacity=0.7,
        hover_data=["DeNombre", variable]
    )

    fig.update_layout(margin={"r":0, "t":0, "l":0, "b":0})

    return fig, df_filtrado.to_dict("records")

if __name__ == "__main__":
    app.run(debug=True)